pp-preempt-v2-async-1f1b 实验结果
=================================
完成时间    : 20260713_102912
代码版本    : async-1f1b (与 graph-opt 同源 + 1F1B 异步恢复)
config      : configs/v2.yaml
nnodes      : 4
stages (k)  : 1 2 3 4
repeats     : 3

文件清单
--------
summary.txt              analyze_v2.py 完整输出(汇总表 + per-trial 表)
summary_v2.csv           per-trial 数据的 CSV 版本(若 pandas 可用)
injection_k*_trial*.json 每个 trial 的原始结果
config_used.yaml         运行时用的配置(供复现)
