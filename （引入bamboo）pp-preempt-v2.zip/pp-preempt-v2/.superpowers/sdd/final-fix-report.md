# Final Fix Report — feat/lm-head-to-stage0

## Fix I1: Restore K-1 exception in `do_retain_here`

**File:** `pp_engine.py`

### Docstring (lines 9, 14)

Before:
```
  · do_retain_here 不再排除 K-1 —— K-1 现在与中间 stage 同性质，参与保留图
  · rank K-1：与中间 stage 同形态，参与 retain_graph_interval 节奏
```

After:
```
  · do_retain_here 仍排除 K-1 —— Ring 拓扑下 K-1 结构同构于中间 stage，
    但按 plan_recovery 定义 K-1 永远不会成为 UPSTREAM_HELPER，
    保留的图无消费者，排除它避免无谓显存
  · rank K-1：与中间 stage 同形态，但不参与 retain_graph_interval（无消费者）
```

### `step()` body (~line 154)

Before:
```python
        # Ring 拓扑：K-1 现在与中间 stage 同性质，所有 rank 都参与
        do_retain_here = do_retain
```

After:
```python
        # Ring 拓扑下 K-1 与中间 stage 结构同构，但按 plan_recovery 的定义
        # K-1 永远不会是 UPSTREAM_HELPER（HELPER 只分配给 rank < target_rank，
        # 而 target_rank ≤ K-1），所以 K-1 保留的图永远没有消费者。
        # 排除 K-1，避免无谓的峰值显存占用。
        do_retain_here = do_retain and (self.rank != self.K - 1)
```

## Fix I1 (spec): Update §6.3 in design doc

**File:** `docs/superpowers/specs/2026-06-22-lm-head-to-stage0-design.md`

Before: stated `do_retain_here = do_retain` with the single bullet "K-1 现在与中间 stage 同性质…需要保留图供 UPSTREAM_HELPER 路径复用".

After: states `do_retain_here = do_retain and (self.rank != self.K - 1)` with four bullets explaining that K-1 is structurally similar but can never be UPSTREAM_HELPER by `plan_recovery` invariant, so the retained graph has no consumer and excluding K-1 avoids dead memory.

## Fix M1: Strengthen `test_stage_first_no_legacy_forward`

**File:** `tests/test_model_layout.py`

Before: only checked `callable(forward_embed)` and `callable(forward_head)`.

After: adds hard assertion `assert "forward" not in StageFirst.__dict__` with explanatory message, which locks the invariant that `_forward_with_clones_method`'s monkey-patch cleanup relies on (restored `saved_forward` must be the base-class stub, not a stale override).

## Fix M2: Drop dead code in `_forward_with_clones_method`

**File:** `pp_engine.py`

Removed the unused `originals` dict (4 lines: init + loop) and the unreachable `saved_forward is None` branch (the `hasattr` guard, the `del` try/except, and the else wrapper). `nn.Module` always defines `forward` at class level, so `hasattr` is always True and the None branch can never execute. Replaced with direct `saved_forward = self.stage.forward`.

## Test run

```
/usr/bin/python3.12 -m pytest tests/test_model_layout.py tests/test_ring_layout_invariants.py tests/test_async_recovery.py::test_plan_recovery_unchanged -v
```

```
collected 16 items

tests/test_model_layout.py::test_stage_first_has_head_and_ln_f PASSED
tests/test_model_layout.py::test_stage_first_no_legacy_forward PASSED
tests/test_model_layout.py::test_stage_first_forward_embed_shape_and_grad PASSED
tests/test_model_layout.py::test_stage_first_forward_head_shape_and_grad PASSED
tests/test_model_layout.py::test_stage_last_no_head PASSED
tests/test_model_layout.py::test_stage_last_forward_preserves_shape PASSED
tests/test_model_layout.py::test_build_stage_rank0_is_stage_first PASSED
tests/test_model_layout.py::test_build_stage_rankK_minus_1_is_stage_last PASSED
tests/test_model_layout.py::test_build_stage_middle PASSED
tests/test_ring_layout_invariants.py::test_stage_first_dual_methods_exist PASSED
tests/test_ring_layout_invariants.py::test_stage_first_has_head_params PASSED
tests/test_ring_layout_invariants.py::test_stage_last_no_head_no_ln_f PASSED
tests/test_ring_layout_invariants.py::test_stage_last_param_names_pure_blocks PASSED
tests/test_ring_layout_invariants.py::test_plan_recovery_target_0 PASSED
tests/test_ring_layout_invariants.py::test_plan_recovery_target_K_minus_1 PASSED
tests/test_async_recovery.py::test_plan_recovery_unchanged PASSED

16 passed, 1 warning in 2.41s
```

Also verified: `pp_engine.py` and `tests/test_model_layout.py` parse clean (`ast.parse`), and `from pp_engine import PPEngine` imports without error.

## Files in commit

- `pp_engine.py`
- `tests/test_model_layout.py`
- `docs/superpowers/specs/2026-06-22-lm-head-to-stage0-design.md`

## Concerns

None. All 16 tests pass. The CUDA warning about old driver is pre-existing and unrelated. The `do_retain_here` change is logically consistent with `plan_recovery`'s UPSTREAM_HELPER assignment invariant (helper rank < target_rank ≤ K-1 means K-1 is never a helper). The dead-code removal in M2 has no behavioral effect — it only simplifies the finally block.
