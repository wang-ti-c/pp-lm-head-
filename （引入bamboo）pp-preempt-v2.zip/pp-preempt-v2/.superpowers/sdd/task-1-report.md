# Task 1 Report: Rewrite model.py with dual-method StageFirst and degenerate StageLast

## Summary

Successfully completed Task 1, which migrates the LM head from stage K-1 (legacy position) to stage 0 (new position) in the ring topology. The model.py file was completely rewritten, and all requirements met.

## Implementation Details

### Step 1: Write Failing Tests
Created `/mnt/c/Users/12589/Desktop/pp-preempt-v2/tests/test_model_layout.py` with 9 tests validating:
- StageFirst has `lm_head`, `ln_f`, `tok_emb`, `pos_emb` attributes
- StageFirst has explicit `forward_embed()` and `forward_head()` methods (no legacy `forward()`)
- StageFirst.forward_embed() produces correct shapes and gradients
- StageFirst.forward_head() produces correct shapes and gradients
- StageLast has NO `lm_head` or `ln_f` (degenerate design)
- StageLast.forward() preserves input shape
- build_stage() factory returns correct classes for each rank

### Step 2: Verify Tests Fail (Expected)
```
FAILED tests/test_model_layout.py::test_stage_first_has_head_and_ln_f - AssertionError: assert False
FAILED tests/test_model_layout.py::test_stage_first_no_legacy_forward - AssertionError: assert False
FAILED tests/test_model_layout.py::test_stage_first_forward_embed_shape_and_grad - AttributeError
FAILED tests/test_model_layout.py::test_stage_first_forward_head_shape_and_grad - AttributeError
FAILED tests/test_model_layout.py::test_stage_last_no_head - AssertionError: assert not True
FAILED tests/test_model_layout.py::test_stage_last_forward_preserves_shape - AssertionError
```
(3 tests passed related to build_stage factory)

### Step 3: Rewrite model.py
Completely replaced `/mnt/c/Users/12589/Desktop/pp-preempt-v2/model.py` with:

**StageFirst class:**
- Attributes: `tok_emb`, `pos_emb`, `drop`, `blocks`, `ln_f`, `lm_head` (all present)
- Method `forward_embed(input_ids)`: Maps [B,T] token IDs through embedding + positional encoding + L Transformer blocks
- Method `forward_head(hidden)`: Maps [B,T,H] hidden states through final layer norm + LM head to logits [B,T,V]
- NO legacy `forward()` method (forces explicit method selection in ring protocol)

**StageLast class:**
- Attributes: ONLY `blocks` (L Transformer blocks)
- NO `ln_f`, NO `lm_head` (degenerate: purely passes hidden states through transformer, returns [B,T,H])
- Method `forward(x)`: Applies transformer blocks and returns hidden states unchanged

**StageMiddle class:**
- Unchanged: passes hidden states through L Transformer blocks

**build_stage() factory:**
- rank == 0: returns StageFirst
- rank == num_stages - 1: returns StageLast  
- else: returns StageMiddle

**Docstring:**
- Updated to Chinese (matching surrounding code style)
- Describes ring topology: "Ring 拓扑布局（LM head 集中到 stage 0）"
- Explains dual methods and role of each stage

### Step 4: Verify Tests Pass
```
tests/test_model_layout.py::test_stage_first_has_head_and_ln_f PASSED    [ 11%]
tests/test_model_layout.py::test_stage_first_no_legacy_forward PASSED    [ 22%]
tests/test_model_layout.py::test_stage_first_forward_embed_shape_and_grad PASSED [ 33%]
tests/test_model_layout.py::test_stage_first_forward_head_shape_and_grad PASSED [ 44%]
tests/test_model_layout.py::test_stage_last_no_head PASSED               [ 55%]
tests/test_model_layout.py::test_stage_last_forward_preserves_shape PASSED [ 66%]
tests/test_model_layout.py::test_build_stage_rank0_is_stage_first PASSED [ 77%]
tests/test_model_layout.py::test_build_stage_rankK_minus_1_is_stage_last PASSED [ 88%]
tests/test_model_layout.py::test_build_stage_middle PASSED               [100%]

========================= 9 passed, 1 warning in 1.01s =========================
```
(CUDA warning is expected in CPU-only environment; immaterial to test correctness)

### Step 5: Sanity Check (Unrelated Test)
```
tests/test_async_recovery.py::test_plan_recovery_unchanged PASSED        [100%]
========================= 1 passed in 0.95s ==========================
```
Confirmed that `plan_recovery` semantics remain unchanged (this test does not import model.py, so pure sanity check).

### Step 6: Commit
```
git add model.py tests/test_model_layout.py
git commit -m "model: ring layout — LM head moves to stage 0, stage K-1 degenerates"
```
Commit SHA: `b464ea6`

## Self-Review Checklist

- [x] model.py docstring updated to reflect ring layout (Chinese: "Ring 拓扑布局（LM head 集中到 stage 0）")
- [x] Docstring matches surrounding code style (uses Chinese comments as per existing code)
- [x] StageFirst has NO legacy `forward()` method; only `forward_embed()` and `forward_head()` exist
- [x] StageFirst attributes: `tok_emb`, `pos_emb`, `drop`, `blocks`, `ln_f`, `lm_head` all present
- [x] StageLast has NO `lm_head` and NO `ln_f` (degenerate: transformer-only)
- [x] StageLast has only `forward()` method (takes [B,T,H] → [B,T,H])
- [x] All 9 tests in test_model_layout.py PASS with pristine output (no extra prints, only 1 CUDA warning which is benign)
- [x] test_plan_recovery_unchanged still PASSES (unrelated test sanity check)
- [x] One commit created with specified message
- [x] No weight tying between tok_emb and lm_head (lm_head is independent Linear layer with bias=False)
- [x] Model hyperparams unchanged (same H, V, L, heads across all stages)
- [x] Did not modify: coordinator.py, checkpoint_v2.py, activation_cache.py, analyze_v2.py, configs/

## Files Changed
- **Modified:** `/mnt/c/Users/12589/Desktop/pp-preempt-v2/model.py` (complete rewrite, ~135 lines)
- **Created:** `/mnt/c/Users/12589/Desktop/pp-preempt-v2/tests/test_model_layout.py` (9 tests, ~75 lines)

## Concerns
None. All requirements met:
- Tests pass with pristine output
- Unrelated test still passes
- Commit created with exact message
- Ring topology correctly implements StageFirst dual-method design and degenerate StageLast
- Ready for next task (pp_engine.py rewrite to implement the ring communication)

## Commands Run
```bash
python3.12 -m pip install --break-system-packages -q torch pyyaml pytest
python3.12 -m pytest tests/test_model_layout.py -v  # FAIL (expected)
# [model.py rewritten]
python3.12 -m pytest tests/test_model_layout.py -v  # PASS (9/9)
python3.12 -m pytest tests/test_async_recovery.py::test_plan_recovery_unchanged -v  # PASS (sanity)
git add model.py tests/test_model_layout.py
git commit -m "model: ring layout — LM head moves to stage 0, stage K-1 degenerates"
```
