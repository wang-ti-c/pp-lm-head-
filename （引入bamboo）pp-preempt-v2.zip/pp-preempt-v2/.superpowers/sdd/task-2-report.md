# Task 2 Report: Ring-closure primitives + PPEngine.step() rewrite

## What was implemented

### New methods
- `_send_hidden_to_head(x)` — rank K-1 sends final hidden to rank 0 via `dist.send(x, dst=0)`
- `_recv_hidden_from_tail() -> Tensor` — rank 0 receives hidden from rank K-1 via `dist.recv(buf, src=K-1)`
- `_send_grad_to_tail(g)` — rank 0 sends grad_hidden to rank K-1 via `dist.send(g, dst=K-1)`
- `_recv_grad_from_head() -> Tensor` — rank K-1 receives grad from rank 0 via `dist.recv(buf, src=0)`
- `_forward_with_clones_method(inp, method_name)` — rank 0 monkey-patches `self.stage.forward` to the named method (e.g. `forward_embed`) before calling `functional_call`, restoring in a try/finally

### Changed methods
- `_forward_with_clones(inp)` — simplified to clean 5-line version (same semantics, removed old docstring verbosity)
- `step()` — fully rewritten:
  - `do_retain_here = do_retain` (removed `< K-1` exception; K-1 is now middle-stage-like)
  - rank 0 forward: calls `forward_embed` (via `_forward_with_clones_method` or direct), sends activation to rank 1
  - rank K-1 forward: receives from rank K-2, runs `self.stage(inp)`, sends hidden back to rank 0 via `_send_hidden_to_head`
  - rank 0: second loop collects hidden from tail, runs `forward_head`, computes loss
  - rank 0 backward: Loop 1 (head backward + `_send_grad_to_tail`), Loop 2 (recv grad from chain + embed backward)
  - rank K-1 backward: `_recv_grad_from_head()`, backward, `_send_grad` upstream
  - Returns `sum(l.item() for l in losses) if self.rank == 0 else 0.0`

## Commands run + output

```
python -c "import ast; ast.parse(open('pp_engine.py').read()); print('ok')"
# ok

pytest tests/test_model_layout.py -v
# 9 passed, 1 warning

pytest tests/test_async_recovery.py::test_plan_recovery_unchanged -v
# 1 passed

git add pp_engine.py
git commit -m "pp_engine: ring-closure primitives + step() with rank 0 loss"
# [feat/lm-head-to-stage0 f583461]
```

## Files changed
- `/mnt/c/Users/12589/Desktop/pp-preempt-v2/pp_engine.py` — whole file replaced

## Self-review findings
- All 4 ring primitives present with exact names from spec
- `_forward_with_clones` is the clean 5-line version
- `_forward_with_clones_method` uses try/finally around monkey-patch; handles `saved_forward is None` vs. not
- `do_retain_here = do_retain` — no `< K-1` exception
- `step()` returns `sum(l.item() for l in losses) if self.rank == 0 else 0.0`
- rank 0 backward has two separate loops as specified
- rank K-1 backward uses `_recv_grad_from_head()`
- test_model_layout.py: 9/9 PASS
- test_plan_recovery_unchanged: PASS

## Concerns
None. The ring-closure comm paths (`_send_hidden_to_head`, `_recv_grad_from_head`, etc.) cannot be exercised in single-process pytest; GPU smoke validation is deferred to Task 8 as specified.
