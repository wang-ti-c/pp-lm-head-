### Task 3: Rewrite execute_recovery_sync for ring topology

**Files:**
- Modify: `recovery_protocol.py` — only `execute_recovery_sync` function (lines 47–172). **Do NOT touch** `plan_recovery`, `RecoveryRole`, or anything in the `1F1B async recovery` section (line 176 onwards).

**Interfaces:**
- Consumes (from Task 2):
  - `engine._send_hidden_to_head(x)`, `engine._recv_hidden_from_tail()`
  - `engine._send_grad_to_tail(g)`, `engine._recv_grad_from_head()`
  - `engine.stage.forward_embed(input_ids)`, `engine.stage.forward_head(hidden)` (when `engine.rank == 0`)
- Produces:
  - `execute_recovery_sync(plan, engine, ckpt_step, resume_step, batch_input_ids, batch_targets, optimizer) -> dict` with shape unchanged from spec:
    ```
    { "activation_resend_sec": float, "recovery_compute_sec": float,
      "stages_resent_activation": list[int], "stages_recomputed_forward": list[int],
      "final_loss": float|None,  # now non-None on rank 0, None elsewhere
      "used_retained_graph": bool }
    ```

- [ ] **Step 1: Replace the `execute_recovery_sync` function**

Open `recovery_protocol.py`. Replace the function body (lines 47–172) with:

```python
def execute_recovery_sync(plan, engine, ckpt_step, resume_step,
                          batch_input_ids, batch_targets, optimizer) -> dict:
    """
    Ring 拓扑下的同步恢复：
      · rank 0 既驱动 embed forward，又消费 rank K-1 回传的 hidden 跑 head + loss
      · rank K-1 退化为中间 stage 同形态（forward 完 send hidden 回 0，等 grad 回来 backward）
      · plan_recovery 角色映射不变；UPSTREAM_HELPER 的 resend cache 行为不变
    """
    rank    = engine.rank
    role    = plan[rank]
    K, M    = engine.K, engine.M

    stages_resent     = [r for r, ro in plan.items() if ro == RecoveryRole.UPSTREAM_HELPER]
    stages_recomputed = [r for r, ro in plan.items()
                         if ro in (RecoveryRole.PREEMPTED, RecoveryRole.DOWNSTREAM_VICTIM)]

    if role == RecoveryRole.UPSTREAM_HELPER and not engine.cache.has_step(ckpt_step):
        raise RuntimeError(
            f"[rank {rank}] UPSTREAM_HELPER missing cache for ckpt_step={ckpt_step}. "
            f"{engine.cache.summary()}"
        )

    use_graph = (role == RecoveryRole.UPSTREAM_HELPER
                 and engine.cache.has_graph(ckpt_step))

    optimizer.zero_grad()

    # ── Forward / resend 阶段 ─────────────────────────────────────────────────
    t0 = time.monotonic()
    fwd_in:   list = []
    fwd_out:  list = []
    head_in:  list = []   # rank 0 only: 收到的 hidden_h3
    losses:   list = []   # rank 0 only

    for mb in range(M):
        if role == RecoveryRole.UPSTREAM_HELPER:
            # rank 0 的 UPSTREAM_HELPER 分支：只 resend cached_out 到 rank 1，
            #   但同时 rank 0 还要兼任 head（在后面的 head loop 里处理）。
            # 其他 rank 的 UPSTREAM_HELPER 分支与原版完全相同。
            if rank > 0:
                _ = engine._recv_act()          # drain buffer
            cached_inp, cached_out = engine.cache.get(ckpt_step, mb)
            fwd_in.append(cached_inp); fwd_out.append(cached_out)
            engine._send_act(cached_out)

        elif role == RecoveryRole.PREEMPTED:
            if rank == 0:
                s = mb * engine.mb_size
                inp = batch_input_ids[s:s + engine.mb_size].to(engine.device)
                fwd_in.append(inp)
                out = engine.stage.forward_embed(inp); fwd_out.append(out)
                engine._send_act(out)
            elif rank == K - 1:
                inp = engine._recv_act(); inp.requires_grad_(True)
                fwd_in.append(inp)
                out = engine.stage(inp); fwd_out.append(out)
                engine._send_hidden_to_head(out)
            else:
                inp = engine._recv_act(); inp.requires_grad_(True)
                fwd_in.append(inp)
                out = engine.stage(inp); fwd_out.append(out)
                engine._send_act(out)

        else:  # DOWNSTREAM_VICTIM
            if rank == K - 1:
                inp = engine._recv_act(); inp.requires_grad_(True)
                fwd_in.append(inp)
                out = engine.stage(inp); fwd_out.append(out)
                engine._send_hidden_to_head(out)
            else:
                inp = engine._recv_act(); inp.requires_grad_(True)
                fwd_in.append(inp)
                out = engine.stage(inp); fwd_out.append(out)
                engine._send_act(out)

    # ── Head / loss 阶段（仅 rank 0，per mb） ────────────────────────────────
    # rank 0 在以下任意角色（PREEMPTED / DOWNSTREAM_VICTIM / UPSTREAM_HELPER）
    # 都必须接收 K-1 发回的 hidden 并算 loss —— 这是 ring 拓扑下 rank 0 的固有职责。
    # （注：target_rank=0 时 rank 0 是 PREEMPTED；target_rank!=0 时 rank 0 是 UPSTREAM_HELPER。）
    if rank == 0:
        for mb in range(M):
            hidden = engine._recv_hidden_from_tail()
            hidden.requires_grad_(True)
            head_in.append(hidden)
            logits = engine.stage.forward_head(hidden)
            s   = mb * engine.mb_size
            tgt = batch_targets[s:s + engine.mb_size].to(engine.device)
            losses.append(F.cross_entropy(
                logits.view(-1, engine.V), tgt.view(-1)) / M)

    resend_sec = time.monotonic() - t0

    # ── Backward / compute 阶段 ───────────────────────────────────────────────
    t0 = time.monotonic()

    if rank == 0:
        # Loop 1: head backward → ring 回传 grad 启动
        for mb in range(M):
            losses[mb].backward()
            engine._send_grad_to_tail(head_in[mb].grad)
        # Loop 2: 等 grad 绕环回到 embed
        if role == RecoveryRole.UPSTREAM_HELPER:
            if use_graph:
                # rank 0 的 helper 路径 A：保留图 backward
                for mb in range(M):
                    g_inp, g_out = engine.cache.get_graph(ckpt_step, mb)
                    g_out.backward(engine._recv_grad())
                    # rank 0 不向上游发 grad
                engine.cache.release_graph_explicitly()
            else:
                # rank 0 的 helper 路径 B：重做 embed + backward
                loc_in, loc_out = [], []
                for mb in range(M):
                    src = fwd_in[mb]
                    inp = src.clone()
                    loc_in.append(inp)
                    loc_out.append(engine.stage.forward_embed(inp))
                for mb in range(M):
                    loc_out[mb].backward(engine._recv_grad())
        else:
            # rank 0 的 PREEMPTED / DOWNSTREAM_VICTIM：直接 backward 现有 fwd_out
            for mb in range(M):
                fwd_out[mb].backward(engine._recv_grad())

    elif role == RecoveryRole.UPSTREAM_HELPER:
        # rank 1..K-2 的 helper（rank K-1 不会是 helper，因为它已是 ring 末端）
        if use_graph:
            for mb in range(M):
                g_inp, g_out = engine.cache.get_graph(ckpt_step, mb)
                if g_inp.grad is not None:
                    g_inp.grad = None
                g_out.backward(engine._recv_grad())
                engine._send_grad(g_inp.grad)
            engine.cache.release_graph_explicitly()
        else:
            loc_in, loc_out = [], []
            for mb in range(M):
                src = fwd_in[mb]
                inp = src.clone().requires_grad_(True)
                loc_in.append(inp)
                loc_out.append(engine.stage(inp))
            for mb in range(M):
                loc_out[mb].backward(engine._recv_grad())
                engine._send_grad(loc_in[mb].grad)

    else:
        # PREEMPTED / DOWNSTREAM_VICTIM on rank 1..K-1
        for mb in range(M):
            if rank == K - 1:
                g = engine._recv_grad_from_head()
                fwd_out[mb].backward(g)
                engine._send_grad(fwd_in[mb].grad)
            else:
                fwd_out[mb].backward(engine._recv_grad())
                engine._send_grad(fwd_in[mb].grad)

    optimizer.step()
    dist.barrier()
    compute_sec = time.monotonic() - t0

    final_loss = (sum(l.item() for l in losses)
                  if rank == 0 else None)

    return {
        "activation_resend_sec":    resend_sec,
        "recovery_compute_sec":     compute_sec,
        "stages_resent_activation": stages_resent,
        "stages_recomputed_forward":stages_recomputed,
        "final_loss":               final_loss,
        "used_retained_graph":      use_graph,
    }
```

**Note on rank-K-1 UPSTREAM_HELPER**: by `plan_recovery`'s definition, rank K-1 can only be `DOWNSTREAM_VICTIM` (it's the last rank). There is no valid `target_rank` that makes K-1 a HELPER. The code above documents this in the comment but doesn't add a defensive check — the role-mapping invariant test covers it.

- [ ] **Step 2: Syntax-check**

Run: `python -c "import ast; ast.parse(open('recovery_protocol.py').read()); print('ok')"`
Expected: `ok`

- [ ] **Step 3: Confirm async path is byte-identical**

Run: `grep -n "execute_recovery_async" recovery_protocol.py`
Expected: the `def execute_recovery_async(...)` signature line is unchanged from the original (line ~329). If anything in the async body changed, revert it.

- [ ] **Step 4: Run plan_recovery test (unchanged behavior)**

Run: `pytest tests/test_async_recovery.py::test_plan_recovery_unchanged -v`
Expected: PASS.

- [ ] **Step 5: Commit**

```bash
cd /mnt/c/Users/12589/Desktop/pp-preempt-v2
git add recovery_protocol.py
git commit -m "recovery: rewrite execute_recovery_sync for ring topology (rank 0 owns loss)"
```

---

