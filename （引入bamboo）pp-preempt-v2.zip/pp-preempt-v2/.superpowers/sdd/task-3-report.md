# Task 3 Report: Rewrite execute_recovery_sync for ring topology

## What was replaced

Replaced the body of `execute_recovery_sync` in `recovery_protocol.py` (original lines 47–172) with the verbatim code block from the task brief. Key structural changes:

- Added docstring (Chinese, matching file style)
- Added `head_in: list = []` alongside `fwd_in`, `fwd_out`, `losses` (changed type annotations from `list[torch.Tensor]` to plain `list`)
- Forward loop: rank K-1 now calls `engine._send_hidden_to_head(out)` instead of computing loss inline; rank 0 PREEMPTED uses `engine.stage.forward_embed(inp)` instead of `engine.stage(inp)`
- Added new head/loss section (rank 0 only): receives hidden via `_recv_hidden_from_tail()`, runs `forward_head`, computes cross-entropy
- Backward loop restructured: rank 0 now drives `losses[mb].backward()` + `_send_grad_to_tail()` (Loop 1), then branches on role for Loop 2 (graph-A / recompute-B / direct fwd_out backward); rank K-1 receives grad via `_recv_grad_from_head()` then sends upstream
- `final_loss` now returns from `rank == 0` (was `rank == K - 1`)

## Verification commands and output

**Syntax check:**
```
python -c "import ast; ast.parse(open('recovery_protocol.py').read()); print('ok')"
ok
```

**Async section unchanged (git diff working tree):**
```
git diff -- recovery_protocol.py | grep -E "^[+-]" | grep -v "^[+-]{3}"
```
All `+` and `-` lines were confined to `execute_recovery_sync` body. No lines from `execute_recovery_async` or the `1F1B async recovery` section (line 176+) appeared in the diff.

**Alternative async check (sed + diff):**
The sed-based diff showed the async section unchanged in the new file — the diff was between the old file's content starting at line 176 vs the new file's async section, confirming byte-identical content.

## Test results

```
tests/test_async_recovery.py::test_plan_recovery_unchanged PASSED
tests/test_model_layout.py::test_stage_first_has_head_and_ln_f PASSED
tests/test_model_layout.py::test_stage_first_no_legacy_forward PASSED
tests/test_model_layout.py::test_stage_first_forward_embed_shape_and_grad PASSED
tests/test_model_layout.py::test_stage_first_forward_head_shape_and_grad PASSED
tests/test_model_layout.py::test_stage_last_no_head PASSED
tests/test_model_layout.py::test_stage_last_forward_preserves_shape PASSED
tests/test_model_layout.py::test_build_stage_rank0_is_stage_first PASSED
tests/test_model_layout.py::test_build_stage_rankK_minus_1_is_stage_last PASSED
tests/test_model_layout.py::test_build_stage_middle PASSED
10 passed, 0 failed
```

## Self-review findings

- execute_recovery_sync function body replaced verbatim from brief: YES
- plan_recovery, RecoveryRole, async section (line 176+) all unchanged: YES
- final_loss returns from rank 0 not K-1: YES (`if rank == 0 else None`)
- rank 0 UPSTREAM_HELPER: receives hidden + computes loss (head loop) + then path A/B for embed backward: YES
- rank 0 PREEMPTED: uses `stage.forward_embed(inp)` not `stage(inp)`: YES
- rank K-1 forward: `_send_hidden_to_head(out)` not `_send_act(out)`: YES
- rank K-1 backward: `_recv_grad_from_head()` then send_grad to K-2: YES
- test_plan_recovery_unchanged PASS: YES
- test_model_layout 9/9 PASS: YES

## Concerns

None. The rewrite is straightforward and all self-review items check out. The async section was confirmed byte-identical by inspecting the working-tree diff. The `execute_recovery_async` function at line 329 was not touched.

## Commit

SHA: 4978e0d  
Subject: recovery: rewrite execute_recovery_sync for ring topology (rank 0 owns loss)
