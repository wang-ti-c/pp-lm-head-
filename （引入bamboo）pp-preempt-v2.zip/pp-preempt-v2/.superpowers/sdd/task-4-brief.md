### Task 4: Flip rank-K-1-owns-loss hardcodes in run_injection_v2.py

**Files:**
- Modify: `run_injection_v2.py` — 6 specific sites listed below

**Interfaces:**
- Consumes (from Task 2 & 3):
  - `PPEngine.step(...)` now returns non-zero loss on rank 0, zero elsewhere
  - `execute_recovery_sync(...)["final_loss"]` is non-None on rank 0, None elsewhere
- Produces:
  - JSON result file written by rank 0 (was rank K-1)
  - `batch_targets` no longer needed by rank K-1

- [ ] **Step 1: Patch `get_step_data` (line ~70)**

Find:
```python
def get_step_data(step, rank, K, M, mb_size, seq_len, vocab_size, seed):
    """返回 (input_ids_or_None, targets_or_None)。中间 rank 两者均为 None。"""
    if rank not in (0, K - 1):
        return None, None
    ids, tgts = make_batch(step, M * mb_size, seq_len, vocab_size, seed)
    return (ids, None) if rank == 0 else (None, tgts)
```

Replace with:
```python
def get_step_data(step, rank, K, M, mb_size, seq_len, vocab_size, seed):
    """返回 (input_ids_or_None, targets_or_None)。
    Ring 拓扑：rank 0 同时拿 input_ids 和 targets（loss 在 rank 0 算）；
    其他 rank 两者均为 None。"""
    if rank != 0:
        return None, None
    ids, tgts = make_batch(step, M * mb_size, seq_len, vocab_size, seed)
    return ids, tgts
```

- [ ] **Step 2: Patch `pre_loss` broadcast (line ~333)**

Find:
```python
    # 广播 pre_loss（只有 rank K-1 有值）
    pre_t = torch.tensor([float(pre_loss)], device=f"cuda:{local_rank}",
                          dtype=torch.float32)
    dist.broadcast(pre_t, src=K - 1)
```

Replace with:
```python
    # 广播 pre_loss（Ring 拓扑：只有 rank 0 有值）
    pre_t = torch.tensor([float(pre_loss)], device=f"cuda:{local_rank}",
                          dtype=torch.float32)
    dist.broadcast(pre_t, src=0)
```

- [ ] **Step 3: Patch loss trajectory accumulator (line ~431)**

Find:
```python
        if rank == K - 1:
            loss_traj.append({"step": step, "loss": round(float(loss), 6)})
```

Replace with:
```python
        if rank == 0:
            loss_traj.append({"step": step, "loss": round(float(loss), 6)})
```

- [ ] **Step 4: Patch Phase E JSON writer (line ~434–436)**

Find:
```python
    # ── Phase E：写 JSON（rank K-1）───────────────────────────────────────────
    if rank == K - 1:
        rec_loss  = rt.get("final_loss")
```

Replace with:
```python
    # ── Phase E：写 JSON（Ring 拓扑：rank 0 持有 loss）─────────────────────────
    if rank == 0:
        rec_loss  = rt.get("final_loss")
```

- [ ] **Step 5: Syntax-check**

Run: `python -c "import ast; ast.parse(open('run_injection_v2.py').read()); print('ok')"`
Expected: `ok`

- [ ] **Step 6: grep-check there's no more `rank == K - 1` ownership pattern**

Run:
```bash
grep -n "rank == K - 1\|rank == K-1" run_injection_v2.py
```

Expected output: only the comment around the old Phase E header is fully replaced; any remaining hits must be examined. The only acceptable remaining hits (if any) are in comments referring to historical context. Lines doing `if rank == K - 1:` to gate behavior must all be gone.

- [ ] **Step 7: Commit**

```bash
cd /mnt/c/Users/12589/Desktop/pp-preempt-v2
git add run_injection_v2.py
git commit -m "run_injection: rank 0 owns loss/trajectory/JSON (was rank K-1)"
```

---

