### Task 5: Adapt test_async_recovery.py infrastructure

**Files:**
- Modify: `tests/test_async_recovery.py` — `_TinyStage`, `_make_engine`

**Interfaces:**
- Consumes (from Task 1): `StageFirst.forward_embed`, `StageFirst.forward_head`, `StageLast.forward`
- Produces:
  - `_TinyStageFirst` — drop-in for rank 0 with `forward_embed` / `forward_head`
  - `_TinyStageTail` — drop-in for rank K-1, no head
  - `_TinyStageMid` — for middle ranks

- [ ] **Step 1: Replace `_TinyStage` class definition**

Open `tests/test_async_recovery.py`. Find:
```python
class _TinyStage(nn.Module):
    """A 1-layer linear stage; matches the (B, S, H) tensor shape of the real stages."""
    def __init__(self, H, V=None, is_last=False):
        super().__init__()
        self.linear = nn.Linear(H, H, bias=False)
        self.is_last = is_last
        if is_last and V is not None:
            self.head = nn.Linear(H, V, bias=False)

    def forward(self, x):
        x = self.linear(x)
        if self.is_last:
            x = self.head(x)
        return x
```

Replace with:
```python
class _TinyStageFirst(nn.Module):
    """Drop-in for rank 0 — mirrors the new StageFirst dual-method API.

    Note: real StageFirst.forward_embed takes token ids; this tiny version
    accepts hidden-shape (B, S, H) tensors instead. The only tests that
    exercise this class today (test_async_returns_required_fields,
    test_loss_consistency_sync_vs_async) are both @pytest.mark.skip'd for
    gloo limitations, so the type mismatch is inert. If those tests are
    ever un-skipped, _TinyStageFirst.forward_embed must be reworked to
    accept LongTensor[B, S] of ids.
    """
    def __init__(self, H, V):
        super().__init__()
        self.linear  = nn.Linear(H, H, bias=False)
        self.ln_f    = nn.LayerNorm(H)
        self.lm_head = nn.Linear(H, V, bias=False)

    def forward_embed(self, x):
        return self.linear(x)

    def forward_head(self, hidden):
        return self.lm_head(self.ln_f(hidden))


class _TinyStageMid(nn.Module):
    def __init__(self, H):
        super().__init__()
        self.linear = nn.Linear(H, H, bias=False)

    def forward(self, x):
        return self.linear(x)


class _TinyStageTail(nn.Module):
    """Drop-in for rank K-1 — pure linear, no head."""
    def __init__(self, H):
        super().__init__()
        self.linear = nn.Linear(H, H, bias=False)

    def forward(self, x):
        return self.linear(x)
```

- [ ] **Step 2: Update `_make_engine` to pick the right tiny stage by rank**

Find:
```python
def _make_engine(rank, K, M, mb_size, seq_len, H, V):
    """Build a PPEngine wrapped around a tiny linear stage."""
    from pp_engine import PPEngine
    torch.manual_seed(1234 + rank)
    stage = _TinyStage(H, V=V, is_last=(rank == K - 1))
```

Replace with:
```python
def _make_engine(rank, K, M, mb_size, seq_len, H, V):
    """Build a PPEngine wrapped around a tiny linear stage matching ring layout."""
    from pp_engine import PPEngine
    torch.manual_seed(1234 + rank)
    if rank == 0:
        stage = _TinyStageFirst(H, V)
    elif rank == K - 1:
        stage = _TinyStageTail(H)
    else:
        stage = _TinyStageMid(H)
```

- [ ] **Step 3: Run plan_recovery test — must still pass without any change**

Run: `pytest tests/test_async_recovery.py::test_plan_recovery_unchanged -v`
Expected: PASS.

- [ ] **Step 4: Confirm skipped tests are still skipped (no regression)**

Run: `pytest tests/test_async_recovery.py -v`
Expected: 1 PASS, 2 SKIPPED.

- [ ] **Step 5: Commit**

```bash
cd /mnt/c/Users/12589/Desktop/pp-preempt-v2
git add tests/test_async_recovery.py
git commit -m "test: adapt _TinyStage to ring layout (StageFirst dual-method)"
```

---

