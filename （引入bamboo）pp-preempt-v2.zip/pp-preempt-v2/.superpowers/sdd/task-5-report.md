# Task 5: Adapt test_async_recovery.py infrastructure — Report

## Status: COMPLETE

### Edits Applied

**File: `tests/test_async_recovery.py`**

1. **Class replacement (lines 44-83)**
   - Removed: `_TinyStage` (1 class, 13 lines)
   - Added: `_TinyStageFirst`, `_TinyStageMid`, `_TinyStageTail` (3 classes, 39 lines)
   
   - `_TinyStageFirst`: Dual-method API matching `StageFirst` (forward_embed / forward_head), includes multi-line docstring explaining the type-mismatch caveat (takes hidden tensors, not token ids)
   - `_TinyStageMid`: Simple linear transform
   - `_TinyStageTail`: Pure linear with NO lm_head / ln_f (matching `StageLast`)

2. **_make_engine dispatch (lines 85-101)**
   - Changed from: `stage = _TinyStage(H, V=V, is_last=(rank == K - 1))`
   - Changed to: Rank-based dispatch
     - rank 0 → `_TinyStageFirst(H, V)`
     - rank K-1 → `_TinyStageTail(H)`
     - else → `_TinyStageMid(H)`

### Test Results

- **test_plan_recovery_unchanged**: ✓ PASS
- **test_async_returns_required_fields**: SKIPPED (gloo limitation — expected)
- **test_loss_consistency_sync_vs_async**: SKIPPED (gloo limitation — expected)
- **test_model_layout.py (sanity check)**: 9/9 PASS

### Files Changed

- `tests/test_async_recovery.py` only

### Commit

- SHA: `fb94197`
- Message: `test: adapt _TinyStage to ring layout (StageFirst dual-method)`

### Self-Review Checklist

- ✓ `_TinyStageFirst` has `forward_embed` / `forward_head`
- ✓ `_TinyStageFirst` includes type-mismatch docstring (multi-line explanation of ids vs. hidden caveat)
- ✓ `_TinyStageTail` has NO `lm_head` / `ln_f`
- ✓ `_make_engine` dispatches by rank correctly
- ✓ `test_plan_recovery_unchanged` passes
- ✓ Skipped tests remain skipped (no regression)
- ✓ Sanity test (model_layout) shows no regression
- ✓ Only `test_async_recovery.py` modified
- ✓ Commit message matches brief

### Concerns

None. The refactor is mechanical and fidelity-only. The two end-to-end tests that exercise `_TinyStage` remain skipped for gloo limitations (as expected), so the new shape is untested in live code but mirrors the production model layout. The binding test (`test_plan_recovery_unchanged`) passes.
