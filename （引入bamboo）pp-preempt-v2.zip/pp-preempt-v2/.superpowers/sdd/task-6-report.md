# Task 6: Add new CPU tests for ring-layout invariants

## Summary
File created and tests passing. No concerns.

## File Created
- `tests/test_ring_layout_invariants.py` — 71 lines, 6 tests

## Test Results

**New tests (focused):**
```
6 passed in 1.14s
```

**Full suite (regression check):**
```
16 passed, 2 skipped in 1.25s
```

## Files Changed
- Created: `tests/test_ring_layout_invariants.py`

## Concerns
None. All 6 tests pass. Full suite shows no regression (16 PASS + 2 SKIP as expected).

## Commit
```
[feat/lm-head-to-stage0 2f321db] test: ring-layout invariants — dual-method head, plan_recovery target_0
 1 file changed, 71 insertions(+)
 create mode 100644 tests/test_ring_layout_invariants.py
```
