### Task 7: Update README.md with ring topology and deployment guidance

**Files:**
- Modify: `README.md`

**Interfaces:**
- Consumes: nothing (documentation only)
- Produces: updated README explaining the new layout

- [ ] **Step 1: Update the file-header docstring at the top of model.py (sanity)**

Already done in Task 1 (the new docstring starts with "Ring 拓扑布局"). No action needed; skip to Step 2.

- [ ] **Step 2: Edit README.md — Stage layout description (early in file)**

Find the existing text near the top (around line 14–24, the "配置对比" table) and **immediately after that table**, insert this new section:

```markdown
## Ring 拓扑（本次改造）

LM head（`ln_f` + `lm_head`）从 stage K-1 永久迁移到 stage 0，数据流由线性
`0→1→2→3` 变为 ring `0→1→2→3→0`：

```
forward（per microbatch）:
  rank 0  : input_ids → tok_emb+pos_emb → 8 blocks → hidden_h0      send → 1
  rank 1  : hidden_h0 → 8 blocks → hidden_h1                          send → 2
  rank 2  : hidden_h1 → 8 blocks → hidden_h2                          send → 3
  rank 3  : hidden_h2 → 8 blocks → hidden_h3                          send → 0  ← 新通道
  rank 0  : hidden_h3 → ln_f → lm_head → logits → cross_entropy → loss

backward:
  rank 0  : loss.backward() → grad_h3                                 send → 3  ← 新通道
  rank 3  : recv grad_h3, blocks.backward → grad_h2                  send → 2
  rank 2  : ... → grad_h1                                              send → 1
  rank 1  : ... → grad_h0                                              send → 0
  rank 0  : recv grad_h0, blocks+emb.backward
```

两个新增 P2P 通道：`K-1 → 0`（forward hidden）和 `0 → K-1`（backward grad）。
其余 `0→1→2→3` / `3→2→1→0` 通道保持不变。

### Stage 容量与部署建议（GPT-2 XL，~1.6B 总）

| stage | 参数构成 | 大小 | 部署建议 |
|---|---|---|---|
| 0 | tok_emb + pos_emb + 8 blocks + ln_f + lm_head | **~610M** | **ondemand**（最重，恢复代价最高）|
| 1 | 8 blocks | ~400M | spot |
| 2 | 8 blocks | ~400M | spot |
| 3 | 8 blocks | ~400M | spot |

把恢复成本高的 stage 集中到 ondemand，其余放 spot —— 这是本次改造的业务动机。

### 范围限制（本次改造）

- 仅修改 sync 恢复路径（`execute_recovery_sync`）
- async 1F1B 恢复路径（`execute_recovery_async`）保持原样，作为后续 spec
- `plan_recovery` 角色映射语义不变
- 不做 weight tying
- 不调整 `num_layers_per_stage`（stage 容量不均衡是本实验要观测的现象）
```

- [ ] **Step 3: Update the "Stage 0 = ... / Stage K-1 = ..." line in the model section**

Search the README for any line describing stage 0 as "Embedding + L 层" or stage K-1 as "L 层 + ln_f + LM Head" outside of the historical context section. If found, update those to reflect the new ring layout. (As of the current README, these descriptions live in the `model.py` docstring itself, not the README, so this step may be a no-op — that is acceptable.)

Run: `grep -n "Embedding + L 层\|ln_f + LM Head" README.md` and update any matches to the new layout. If nothing matches, this step is a no-op.

- [ ] **Step 4: Update the "文件改动相对 graph-opt" table at the bottom of README**

Find the table starting "| 文件 | 状态 |" near the bottom of README.md. Append two new rows at the top of the rows block (just below the header `|---|---|`):

```markdown
| `model.py` | **本次改造**：StageFirst 双方法 (forward_embed/forward_head)，StageLast 移除 head |
| `pp_engine.py` | **本次改造**：新增 4 个 ring-closure 通信原语，step() 重写，rank 0 owns loss |
| `recovery_protocol.py` | **本次改造**：execute_recovery_sync 重写（async 路径不动）|
| `run_injection_v2.py` | **本次改造**：6 处 rank K-1 ownership 翻转为 rank 0 |
```

(The existing rows for those files in the "graph-opt 对比" table can stay — they describe prior history.)

- [ ] **Step 5: Verify README renders sensibly**

Run: `head -80 README.md` and skim the inserted ring topology section. Confirm the ASCII diagram is intact and tables look right.

- [ ] **Step 6: Commit**

```bash
cd /mnt/c/Users/12589/Desktop/pp-preempt-v2
git add README.md
git commit -m "docs: ring topology section + deployment guidance table"
```

---

