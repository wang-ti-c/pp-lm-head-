# Task 7 Report: README.md Ring Topology Update

## Summary

Successfully completed all 6 steps of Task 7. README.md updated with new ring topology section and deployment guidance.

## Details

**Insertion Location:** New "Ring 拓扑（本次改造）" section inserted after line 24 (after "每 stage 显存估算..." line), immediately before "## 与前三组的关系" section at lines 26-77.

**Step 3 (grep):** `grep -n "Embedding + L 层\|ln_f + LM Head" README.md` returned no matches — this step is a no-op as expected.

**Files Changed:** README.md (47 insertions, 2 deletions)

**Commit:** `6e9f2e3` — `docs: ring topology section + deployment guidance table`

## Sections Inserted

1. Ring 拓扑（本次改造）section with complete ASCII diagram (forward/backward flow)
2. Stage 容量与部署建议 sub-table with capacity and deployment recommendations
3. 范围限制（本次改造）sub-section with 5 bullet points
4. Updated 文件改动相对 graph-opt table: added 4 rows at top (model.py, pp_engine.py, recovery_protocol.py, run_injection_v2.py with "本次改造" markers)

## Verification

- Rendered output verified via `head -80 README.md`: ASCII diagram intact, tables formatted correctly
- No content removed beyond what brief specified
- Only README.md in commit

## Concerns

None. All steps completed as specified.
